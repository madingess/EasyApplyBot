How to run Windows executable?

Windows executable version  of  EasyApplyBot enables
you to run this bot without any hassle about Python.

Follow these steps:
1. Update 'config.yaml' for your profile
2. Open 'windows' folder
3. Right click > select 'open in terminal' (or cmd)
4. Type '.\EasyApplyBot.exe' (or just type Easy and press tab key)
5. Press enter to run the Easy Apply bot